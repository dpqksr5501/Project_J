# 애니메이션

현재 동작을 이해할 때는 아래 파이프라인과 목적별 기준 문서를 읽는다. 제작은 [Authoring](Authoring/README.md), 증상·원인은 [Diagnostics](Diagnostics/README.md), 이미 구현한 기능·과거 제안·인계의 구분은 [Planning 목차](Planning/README.md)에서 찾는다.

공통 master/source Skeleton은 UE5 Manny `SK_Mannequin`이다. 현재 이름은 `ABP_Player_Master` / `UProject_JPlayerAnimInstance`다. UEFN 라이브러리 448개를 Manny용으로 한 번 변환하고 생산 Chooser·PSD·BlendSpace를 변환본으로 이관한다. 원본은 보존하고, 현재 Bip01 몸체만 Manny에서 runtime retarget한다. UE5 몸체 직접 연결과 망토 등 추가 뼈의 native CopyPose/Post Process 제작 경계는 [스켈레톤·추가 뼈 가이드](Authoring/HumanoidSkeletonRetargetingStandards.md)를 따른다.

UEFN→Manny 후속 점검에서 이름으로 출력하는 Chooser 블렌드 프로필, Manny용 BlendStack 미러 메타데이터와 생산 Branch PSD 후보를 정리했다. 현재 회귀 실행기는 로코모션·몸체 리타깃·접촉·시각 소유권을 함께 검증한다. 세부 변경과 검증 경계는 같은 이관 문서의 후속 점검 절을 따른다. 이후 UEFN 직접 재생용 호환 등록과 구형 몸체 리타깃·비교본·리디렉터, 완료된 일회성 이관 API를 백업 후 정리했다. 원본 재제작 경로와 현행 공용 데이터는 유지한다.

**현재 로코모션은 GASP 5.8 Mover 기반이다.** 최신 계약·실제 검증·보존 자료는 [Mover 로코모션 이관](Architecture/GASP58_Locomotion_Migration_2026-10-19.md)을 따른다. OTM/Strafe와 Project_J 공중 방향 재선택을 유지한다. 활성 ABP의 미사용 MM/slide/MMI 경로는 정리했으며, Strafe Sprint는 전방 세 방향을 승인하고 측후방 공중 선택은 최신 Run 값으로 갱신한다. 콜백·제작·테스트용 자원의 보존 이유와 검증은 같은 이관 문서의 마지막 절에 기록한다. 아래 기존 R19/R20·CMC 기록은 이전 기반의 이력이며 새 구조의 검증과 합산하지 않는다.

2026-10-20 후속 작업에서 전신 몽타주 Slot을 GASP 절차 보정 뒤로 이동해 하체 덮어쓰기를 수정했다. 생산 그래프·후보·공중 선택 회귀는 `ProjectJ.PlayerLocomotion`로 이관했다. 구형 Master/Player ABP·독립 PSD/PSS·정규화·Chooser·MM 세트 89개는 호출자 이주와 참조 폐쇄·백업 확인 후 퇴역했다. 현재 지상 내장 PSD와 GASP 원본 제작·비교 자원은 보존한다. [현재 제작·회귀 실행 기준](Architecture/GASP58_Locomotion_Migration_2026-10-19.md#전신-몽타주-수정과-gasp-제작회귀-정착-2026-10-20)을 따른다.

감사별 변경·시험 조건·성능 미해결 범위는 [검토 목차](../Review/README.md)로 모았다. 과거 검사 횟수나 통과 수는 현재 전체 품질의 보증으로 사용하지 않는다.

현행 클립 448개의 GASP 5.8 원본 비교와 구버전 클립 270개 퇴역, 점프의 잔여 이름 노티파이 20개 정리는 [애니메이션·노티파이 비교 결과](Architecture/GASP58_Locomotion_Migration_2026-10-19.md#로코모션-클립노티파이-원본-비교와-구버전-정리-2026-10-20)를 따른다. 이전 경로의 점프 21개도 원본과 동일한 모션·커브를 유지하므로 경로명만으로 교체하거나 삭제하지 않는다.

2026-10-21 이후 실제 재생은 위 원본에서 변환한 Manny 라이브러리를 사용한다. 원본 비교 기록을 Manny 변환본의 시각 품질 승인으로 해석하지 않는다. 새 [Manny 변환·Player 명명 검증](Architecture/GASP58_Locomotion_Migration_2026-10-19.md#manny-라이브러리-변환과-player-명명-정착-2026-10-21)에서 현재 빌드·36개 회귀·실제 PIE·정상 종료 결과를 확인한다.

이후 다리 펴짐 재현에서 변환기의 루트/발 목표 공간과 고정 IK 보조 뼈, 발 Rig의 UEFN 초기화 기본값을 수정했다. [다리 포즈·실제 Rig 검증](Architecture/GASP58_Locomotion_Migration_2026-10-19.md#manny-다리-포즈와-발-rig-실행-경로-수정-2026-10-21)이 현재 후속 기준이다. `Validate-MannyRetargetedKinematics.py`는 변환 포즈를, 지상 PIE 검사는 실제 생성된 Manny 발 Rig를 확인한다. Skeleton의 다리 Translation Retargeting을 일괄 변경하지 않는다.

현재 GreatSword_Woman의 LOD0–2는 사용자 검토 후 채택했으며 LOD3–4 추가는 보류한다. 새 캐릭터·의상·장비는 [공통 LOD 제작](Authoring/Mesh_LOD_Authoring.md)을 사용한다. 기존 체인은 보존하며 LOD가 없는 일반 표면 메시만 명시적으로 생성·검증한다. Cloth·헤어·morph 등은 원본을 유지하고 각 native 제작 경로로 검수한다. [7차 구현·검증](../Performance/Planning/ProjectJ_200_Player_Optimization_Plan_2026-10-15.md#10월-15일-7차--새-캐릭터의상장비의-공통-lod-제작)에 저장 후 재검사와 로컬 무기 품질 보호를 기록했다.

[6차 최적화](../Performance/Planning/ProjectJ_200_Player_Optimization_Plan_2026-10-15.md#10월-15일-6차--다른-에셋-호환성과-실제-몸체-lod)는 다른 에셋의 Cloth/외부 제어·역할 충돌을 보호하고 원격 body의 실제 화면 크기 LOD를 사용한다. 기존 body에 LOD1·2를 추가했으며 로컬은 기존LOD0·포즈/물리를 유지한다. 반복 GPU 이득과 미확정인 전체 frame/CPU 이득을 구분한다. 새 캐릭터/망토/헤어의 제작·접촉·LOD 전환 검수는 여전히 에셋별로 필요하다.

최적화의 현재 목표는 **총 200명 전원 표시와 로컬 품질 유지**다. [계획과 첫 적용·검증](../Performance/Planning/ProjectJ_200_Player_Optimization_Plan_2026-10-15.md)은 기존 예산 subsystem의 거리 관측 활성화와 로컬 중복 계산 정리, 200명 렌더·로컬 품질·원격/전투 회귀를 기록한다. 동시 공격의 리타깃·의상 비용과 일부 CPU 증가는 남아 있으며 전체 성능 개선 완료로 판정하지 않는다.

3차에서는 원격 retarget IK 생략을 실제 구현·포즈·교대 CPU로 시험했으나 비용 절감을 입증하지 못해 제거했다. 당시 2차 runtime을 보존했고 실험용 CVar/분기를 남기지 않았다. 이후 6·7차의 공통 경계·몸체 LOD·제작 경로는 별도로 반영했다. [미채택 근거와 후속 범위](../Performance/Planning/ProjectJ_200_Player_Optimization_Plan_2026-10-15.md#10월-15일-3차--원격-리타깃-ik-소비)를 확인한다.

4차에서는 op별 비용과 실제 physics actor를 읽는 Editor 진단을 추가했다. 의상 전용 데이터 축소는 단순 복제 대조군의 동등성도 확보되지 않아 보류했고 제작 에셋·runtime은 유지했다. [실제 관측·실패 근거·다음 검증](../Performance/Planning/ProjectJ_200_Player_Optimization_Plan_2026-10-15.md#10월-15일-4차--실제-연산-비용과-의상-데이터-분리-검증)을 함께 읽는다.

후속 [5차](../Performance/Planning/ProjectJ_200_Player_Optimization_Plan_2026-10-15.md#10월-15일-5차--물리-복제의-초기화-동등성과-비용-판정)에서 시험의 비대칭 초기화 순서를 고쳐 단순 복제와 축소본900표본이 동등성을 통과했다. 91→44 actor 축소는 비계측 비용 이득이 대부분1% 안팎이고 trace의 대조 scope 변동도 남아 미채택했다. 생산 몸체에 강제 reset/새 상태를 추가하지 않고 Editor 회귀만 남겼다.

같은 계획의 2차는 전반적 locomotion 경로의 작은 조회 정리, 비계측 교대 비교와 실제 Body IK/물리/LOD 소비를 추가한다. Far 정책값만으로 리타깃 IK가 비활성화됐다고 판단하지 않는다. 전체 성능 효과가 미확정인 부분과 RHI34개·최종200명/local 품질 검증을 구분해 기록했다.

## 현재 플레이어 파이프라인

Mover의 실제 이동·입력·궤적 snapshot을 native GASP AnimInstance가 계산하고 State Controller/Pose Match Chooser/BlendStack에 공급한다. SmoothWalking 이동 조정, 상태 계산·선택 조건·Chooser 실행은 C++가 소유하며 ABP의 포즈 노드·전환 연결과 Chooser 제작 데이터는 유지한다. 점프는 Project_J의 방향 재선택을 유지하고 일반 추락은 원본 GASP 선택을 사용한다. 같은 소스 포즈에 전투 상체·몽타주·탈것 레이어를 합성하고, 임포트 몸체는 런타임 리타깃·Guided Hand IK·의상 물리를 평가한다. 무기 구동과 손 접촉의 책임은 분리한다.

2026-10-12의 `ABP_Humanoid_Master`/`Project Unified Locomotion`과 아래 R19/R20·곡선/MM 후보군 문서는 이전 기반의 구현 이력이다. 현재 진입점은 `ABP_ProjectJ_GASP58`이며 최신 소유권과 검증은 위 이관 문서가 기준이다.

| 목적 | 기준 문서 |
| --- | --- |
| Mover·애니메이션 전환 후 소스·입력 승인/소유권 재점검 | [2026-10-20 소스 재점검](../Review/Audits/Project_J_Mover_Animation_Source_Reaudit_2026-10-20.md) |
| 현재 Mover/SmoothWalking·GASP 지상 구조·ABP 전체 함수 대조·점프 재선택과 실제 검증 | [GASP 5.8 Mover 이관](Architecture/GASP58_Locomotion_Migration_2026-10-19.md) |
| 대각 점프·착지의 실제 sample 보정 초기화 | [R20 보정 복구](../Review/Audits/Project_J_Strafe_Diagonal_Warp_Repair_2026-10-15.md) |
| 대각 Stand 착지 선택과 현재 Chooser·입력 대조 | [R19 소스·데이터 대조](../Review/Audits/Project_J_PC_Source_Data_Reconciliation_2026-10-15.md) |
| 후진 중 몸 방향 전환과 Cycle 복귀 | [후진 Reface 구현](Planning/GASP_Backward_Reface_Implementation_2026-10-12.md) |
| 이전 기반의 Mirror 도입 보류 결정·국소 재검토 조건 | [Mirror Data 도입 보류](Planning/Mirror_Data_Adoption_Decision_2026-10-15.md) |
| 골격·몸체 프로필 공유, 실제 리타깃/손 접촉 연결과 호환·수명 검증 | [실시간 리타깃 프로필](Architecture/Runtime_Retarget_Profiles_2026-10-13.md) |
| 스냅샷·표시·검색·복귀·품질 예산의 경계와 동작 보존 검증 | [파이프라인 리팩토링](Architecture/Animation_Pipeline_Refactor_2026-10-13.md) |
| 이전 기반 단발·MM 공통 재생 스택과 ABP 노드 역할 | [통합 Locomotion 구현](Planning/Unified_Locomotion_Implementation_2026-10-12.md) |
| 느린 OTM/Strafe 회전·미세 입력·State Controller·미사용 함수 정리 | [지속 곡선 판정과 Master 정리](Planning/Sustained_Curve_And_Master_Cleanup_2026-10-12.md) |
| 좌우 곡선 반전의 후보 유지·전방 입력 묶음의 예측 안정화 | [사용자 로그 후속 구현](Planning/Sustained_Curve_And_Master_Cleanup_2026-10-12.md#사용자-로그-후속-곡선-반전과-전방-예측-안정화) |
| W 미세 회전의 Loop·곡선 공동 후보·정규화 참조 보정·실제 로그 재생 | [전방 Strafe Run 후속](Planning/Sustained_Curve_And_Master_Cleanup_2026-10-12.md#전방-strafe-run-미세-회전-후속-구현) |
| W 곡선의 전방 후보 구성과 A/D 측면 후보 보호 | [전방 이동 의도별 PSD 구성](Planning/Strafe_Forward_Intent_2026-10-13.md) |
| 착지 후 약한 회전의 후보 소유권·후속 Arc/Loop의 보간 일관성·숙인 상체의 yaw 오해 방지 | [Strafe Land 복귀 보완](Planning/Strafe_Land_Return_2026-10-13.md) |
| 200명 리타깃·의상 물리 예산·보간·병렬 경계·off/on 결과 | [시각 애니메이션 예산 구현과 검증](Planning/Crowd_Visual_Presentation_Budget_2026-10-12.md) |
| 실제 그래프 기반 GASP 비교·자연스러움 고도화·후속 프롬프트·PDF | [2026-10-06 조사와 고도화 인계](Planning/GASP_ProjectJ_Naturalness_2026-10-06/README.md) |
| 이동 상태·GASP 대응 확인 | [Locomotion](Locomotion/README.md) |
| Motion Matching 실행·원격·예산 정책 | [Motion Matching 구조와 후속 항목](Architecture/MotionMatchingNextSteps.md) |
| 이전 외부 Blend Stack 복귀·현재에도 사용하는 검색 예산의 보완 이력 | [복귀 검색과 군중 예산 보완](Architecture/MotionMatching_Return_Crowd_2026-10-05.md) |
| 통합 이전의 외부 단발→MM 크로스페이드·관성 복귀 비교 이력 | [Live Return 구조와 당시 검증](Architecture/OneShot_Live_Return_2026-10-11.md) |
| Start·Land 작은 입력 유지·지속 곡선의 Cycle 복귀·첫 MM 후보 전달 | [단발 입력 반응과 첫 검색](Architecture/OneShot_Input_Response_2026-10-11.md) |
| Strafe A/S/D 카메라 회전의 예측 흔들림·재선택 비교 | [Strafe 예측 안정화](Architecture/Strafe_Prediction_Stability_2026-10-11.md) |
| 전방 Strafe Arc의 실제 몸통 방향·원본 자세 비교 | [전방 몸통 진단](Architecture/Strafe_Forward_Facing_Diagnostics_2026-10-11.md) |
| Master 공통 상체 방향·프로필 뼈 역할·LOD·보호 포즈 검증 | [Strafe 상체 방향 보정](Architecture/Strafe_Upper_Body_Facing_2026-10-11.md) |
| 전방 Strafe Run의 골반 방향·기존 발 접지 제약·Turn/몽타주 제외 | [Strafe 하체 방향 보정](Architecture/Strafe_Lower_Body_Facing_2026-10-11.md) |
| Strafe 네 방향 Pivot·입력 취소 | [Pivot 이동 입력 기준 통일](Architecture/Strafe_Pivot_Input_Basis_2026-10-05.md) |
| 연속 Pivot·OTM/Strafe 중복 Start/Land 방지 | [일회성 동작의 요청 수명](Architecture/OneShot_Command_Lifetime_2026-10-05.md) |
| Start·착지 중 입력 변경·MM 복귀의 실행 흐름 | [기본 비활성 흐름 진단](Architecture/Start_Land_Input_Flow_Trace_2026-10-05.md) |
| 이동 착지 취소의 Idle 경유·연결 레이어 검색 완료 수정 | [착지 복귀와 연결 레이어 검색](Architecture/Landing_Return_Linked_Search_2026-10-05.md) |
| 실제 BP 군중 CPU·소켓 검증과 동시 공격 비용 | [실제 캐릭터 애니메이션 검증](Architecture/Authored_Animation_Crowd_Network_2026-10-05.md) |
| OTM·Strafe 이동 중 180도 Turn의 조건·요청 수명·PSD 연결 | [이동 중 180도 Turn](Architecture/Moving_Turn_180_2026-10-06.md) |
| 리타깃 파이프라인과 배경 | [런타임 리타깃 구조](Architecture/Runtime_Retarget_HandIK_Architecture.md) |
| 무기 부착·파지·궤적·공격 종료 복귀 | [무기 파지와 손 접촉 통합 가이드](Authoring/Weapon_Hand_Contact_System.md) |
| 외형·의상 리더 선택 | [외형 메시 소유권](Architecture/Visual_Presentation_Mesh_Ownership.md) |
| 발소리·지형 매핑·클라이언트 군중 오디오 기반 | [캐릭터 Foley 시스템](Architecture/Foley_Audio_System.md) |
| 실제 GASP 노티파이·오디오 뱅크·재생 경로 조사 | [GASP Foley 조사](Diagnostics/GASP_Foley_Investigation_2026-10-08.md) |
| GASP BP 노티파이의 native 교체·설정 보존·검증 | [Foley 노티파이 교체](Diagnostics/Foley_Notify_Migration_2026-10-08.md) |
| 이벤트 대체·발/손/소켓 정책·초기 마네킹 음원 연결 | [Foley 확장과 연결](Diagnostics/Foley_Extension_2026-10-08.md) |
| 정면 달리기의 객체 없는 노티파이 복구·실제 MM 재생 검증 | [정면 달리기 Foley 복구](Diagnostics/Foley_Forward_Run_Fix_2026-10-08.md) |

## 에디터 제작과 디버깅

1. [제작 가이드](Authoring/README.md): 몸체 DA, Palm·WeaponGrip 소켓, ABP의 오른팔·왼팔 연결.
2. [진단 기록](Diagnostics/README.md): 파지·팔꿈치·TIP의 로그와 수정 근거.
3. [계획](Planning/README.md): 파이프라인 제안과 스레딩 감사의 후속 범위.

현재 대검의 확인된 구성은 Idle 오른손 파지 → Two-Hand Grip IK 구간 양손 파지 → 왼손 해제다. 다른 무기는 보조 접촉 기능과 기본 가중치로 한손·항상 양손을 선택한다. 세부 설정은 [통합 가이드의 보조 손 절](Authoring/Weapon_Hand_Contact_System.md#secondary)에 모은다.

상체 전투 합성은 [전투](../Combat/README.md), 원격 복제 검증은 [네트워크](../Networking/README.md), 다수 플레이어 비용은 [성능](../Performance/README.md)에서 확인한다.
