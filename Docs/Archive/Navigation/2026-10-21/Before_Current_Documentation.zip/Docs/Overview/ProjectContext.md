# Project J 프로젝트 맥락

이 문서는 Project J의 **현재 구조와 작업 기준을 빠르게 파악하는 맥락 문서**다. 전투/애니메이션만이 아니라 런타임 소유권, 데이터, 네트워크, 탈것, UI와 향후 MMORPG 확장 경계를 함께 다룬다.

2026-10-21에는 UEFN 호환 직접 재생의 팔 자세 차이를 확인해 448개 시퀀스와 BlendSpace 10개를 Manny용으로 변환했다. 생산 Chooser·내장 PSD·가산 base·Branch In 참조를 변환본으로 이관하고 원본 파일은 보존했다. 마스터와 native 부모는 `ABP_Player_Master` / `UProject_JPlayerAnimInstance`, 이동 에셋은 `Animation_Logic/PlayerMovement`, 회귀 이름은 `ProjectJ.PlayerLocomotion`이다. OTM/Strafe·전방 3방향 Strafe Sprint와 기존 점프 재선택/playhead는 유지한다. 현재 결과·종료 중 충돌 이력과 검증 경계는 [이관 기록의 2026-10-21 항목](../Animation/Architecture/GASP58_Locomotion_Migration_2026-10-19.md#manny-라이브러리-변환과-player-명명-정착-2026-10-21)을 따른다.

> 상세한 구현 규칙은 각 전문 문서가 기준이다. 이 문서는 현재 구조를 빠르게 파악하기 위한 진입점이며, 에셋의 정확한 할당값은 에디터에서 최종 확인한다.

같은 날 다리 펴짐 후속 수정에서 변환본의 FK/IK 공간과 IK 보조 뼈를 바로잡고, 실제 실행 시 UEFN 발 Rig로 돌아가던 초기화 기본 참조를 Manny로 이관했다. 모션 재제작은 `RTG_Player_UEFN_to_Manny`를 기준으로 하며 기존 에셋의 뼈 트랙을 삭제 없이 갱신한다. 그래프·컴파일된 기본값·실제 Rig 생성과 포즈 검증의 구분은 [후속 기록](../Animation/Architecture/GASP58_Locomotion_Migration_2026-10-19.md#manny-다리-포즈와-발-rig-실행-경로-수정-2026-10-21)을 따른다.

UEFN→Manny 후속 점검에서는 Chooser의 이름 기반 블렌드 프로필 출력, BlendStack 미러 메타데이터, production Idle Branch PSD의 개발용 비교 후보를 수정했다. 재제작용 원본과 Manny 전투 프로필은 유지한다. 현재 제작 계약은 [스켈레톤 제작 기준](../Animation/Authoring/HumanoidSkeletonRetargetingStandards.md)의 프로필·미러·후보 분리를 따른다. 이후 구형 몸체 리타깃 세트·초기 비교본·미참조 리디렉터 8개와 완료된 일회성 이관 API 3개를 퇴역했다. UEFN 직접 재생용 호환 등록은 양방향에서 해제하고 테스트도 Manny 직접 재생으로 전환했다. 재제작용 원본과 현재 공용 데이터는 유지한다.

마스터의 BP 상태 92개는 native 상속 프로퍼티로 이관했고 BP 소유 변수는 0개다. 지상 전환 21개의 조건과 클립별 Steering 핀도 C++가 계산한다. 포즈 노드와 콜백 시점은 유지하고, 제작·테스트 관찰도 `Player*` native 계약을 사용한다. 현재 상태/튜닝 소유권·외부 BPI 경계와 검증은 [native 이관 기록](../Animation/Architecture/GASP58_Locomotion_Migration_2026-10-19.md#native-상태핀-계약-이관-2026-10-21)을 따른다.

2026-10-19의 [MMORPG 아키텍처 대조](../Review/Architecture/Project_J_MMO_Architecture_2026-10-19.md)는 앞 단계 이력이며, [현재 잔여 작업 상태](../Review/Architecture/Project_J_MMO_Remaining_2026-10-19.md)가 ZIP 전체 권고와 후속 구현·검증의 현재 판정 기준이다. 장비 상세/공개 복제 분리, PS 명령 예산, 요청 payload와 receipt 결합, 소셜 접속 교체 후 쓰기 철회와 Gateway byte 경계를 적용했다. 운영 인증·네트워크/Shipping 영속 저장·실제 존 이전·미래 카탈로그 기능은 구현 완료와 구분한다.

2026-10-20 사용자 요청으로 [GASP 5.8 Mover 로코모션 이관](../Animation/Architecture/GASP58_Locomotion_Migration_2026-10-19.md)과 후속 C++ 계산 전환·활성 BP/ABP 정리 및 공중 재선택 수정을 반영했다. 이동 튜닝·지상 이동 조정, ABP 프레임 계산·선택 조건·Chooser 호출은 native가 소유하고 State Controller/Pose Match/BlendStack의 포즈 그래프와 제작 데이터는 유지한다. OTM도 공중에서 입력 facing으로 회전하며 GASP Falling 회전 offset·착지 전환과 Project_J 재선택/playhead를 연결했다. 공중 제어는 가속도에 적용하고 입력 해제 시 수평 관성을 보존한다. 네트워크는 원본 GASP의 Independent/Interpolated 정책과 메시·카메라 시각 보간을 사용한다. Fixed 대조에서 발생한 보간 오류와 원격 착지 중복 writer를 확인해 후자를 제거하고 실제 소켓 회귀로 정책을 검증했다. Strafe의 앞쪽 3방향 Sprint와 GAS·장비·탈것·리타깃을 보존한다. 후속 정착 작업에서 전신 Slot을 절차 보정 뒤로 옮겨 스킬 하체 포즈를 보호했다. 회귀·제작 경로를 GASP 기준으로 이주하고 구형 전용 에셋 89개를 백업·참조 확인 후 퇴역했다. 실제 점프 정책·현재 내장 PSD와 원본 GASP 제작·비교 자원은 보존한다. 현재 실행 기준은 `Scripts/Validation/Run-PlayerLocomotionRegression.ps1`과 이관 문서의 마지막 절이다. 이전 CMC 유지·Pivot 중심 작업은 역사 자료다. 현재 반영·검증과 초기 네트워크 동기화 경고 등 한계는 이관 문서를 따른다.

2026-10-15의 main 통합·R19/R20·소스/BP/DA 정리와 보류 범위는 [검토 목차](../Review/README.md)를 따른다. 애니메이션의 현재 계약은 [주제 목차](../Animation/README.md)에 모으며, GASP가 참조하는 기존 Mirror Data 자원은 함께 이관했으며, 이전 독자 Mirror 계층의 도입 보류 문서와 구분한다. 이전 인계의 전체 감사 요청을 현재 작업 지시로 자동 재개하지 않는다.

2026-09-19의 기반 변경은 [갱신·수명 정리](../Architecture/Runtime/Reports/Internal_Polish_2026-09-19.md)에 기록했다. GAS Tick은 엔진의 필요 기반 정책을 사용하고, 탈것 체력은 GAS가 원천이며 기존 Actor 필드는 호환 조회값이다. 콘텐츠 작성은 기존 DA 구조와 [직업·전직 묶음 제작 도구](../Gameplay/Authoring/Content_Authoring_System.md#tool)를 함께 사용한다.

2026-10-13의 실제 후속 구현은 [전체 결함 감사](../Review/Audits/Project_J_Whole_Project_Audit_2026-10-13.md)와 [구조 개선](../Review/Audits/Project_J_Structural_Improvement_2026-10-13.md)에 기록한다. 후자는 레이어·UI 자원 수명 공통화, UI/무기 진단 책임 분리, private 미사용 제거와 늦은 Controller의 GAS metadata 갱신이며, 검토만 한 시스템·미해결 CPU 증가와 구분한다.

이전 통합 검증은 [2026-09-19 기록](../Architecture/Runtime/Reports/Internal_Polish_Validation_2026-09-19.json)이다. 후속 캐릭터 변경과 검증 범위는 [2026-09-20 컴포넌트 실행·수명 정리](../Architecture/Runtime/Reports/Character_Component_Ownership_2026-09-20.md)를 따른다. UI는 소비 수명에 따라 구독하고, 임시 애니메이션 요구는 메시에서 합성하며, 발도·납도 실행 상태는 기존 CombatIntroComponent가 소유한다. 궤적은 현재 생성 경계를 유지한다. 자동화 기록은 실제 멀티플레이·제작 메뉴·에셋 저장의 수동 확인을 대신하지 않는다.

2026-10-20 후속 [Mover·애니메이션 소스 재점검](../Review/Audits/Project_J_Mover_Animation_Source_Reaudit_2026-10-20.md)에서 기록된 명령 기준 Strafe Sprint 승인, custom 입력의 숫자 검증과 무소유 Pawn의 입력 해제, 실제 초기화·종료 경고를 보완했다. 보간 시계의 첫 접속과 긴 프레임 처리는 프로젝트 `Plugins/NetworkPrediction` 패치를 사용하며, 모듈 의존성상 동일 버전의 수정 없는 `Plugins/Mover`도 함께 빌드한다. 설치 엔진은 유지하고 100/250ms 설정을 확대하지 않았다. 공중 재선택·OTM/Strafe는 유지하며 native 회귀·실제 입력·버퍼 계측은 해당 기록과 플러그인의 패치 설명을 따른다.

## 1. 프로젝트 성격과 현재 범위

- Unreal Engine **5.8** 기반의 3인칭 액션 MMORPG 지향 프로젝트다.
- 핵심은 C++ 기반 캐릭터 이동, GAS, 데이터 기반 직업/장비/전투, 네트워크 권한, 그리고 GASP 5.8 기반 로코모션 애니메이션이다.
- 현재 기본 맵은 `Lvl_ThirdPerson`, 기본 GameMode는 `BP_Project_JGameMode`다. 이 Blueprint는 `Project_JGameMode`를 상속하고, GameState/PlayerState는 C++ 클래스다. 실제 CDO의 Pawn은 `BP_GreatSword`, Controller는 `BP_ThirdPersonPlayerController`의 override다. Third Person 샘플 에셋이 남아 있지만 최종 게임 구조를 의미하지는 않는다.
- 대검은 첫 번째 실제 직업 수직 슬라이스다. `BP_Player`는 공통 아바타 제작 기반이며, 생산 대검·NPC와 함께 `ABP_Player_Master`를 사용한다. 구형 `ABP_Player`는 퇴역했다.
- 아직 실제 백엔드/메가서버/거래소/길드/대규모 군중을 완성한 상태가 아니다. 관련 타입과 경계는 장래 확장을 위해 존재한다.
- NPC 타깃 후보는 중앙 스케줄러의 공간 질의를 사용하며, 장비 메시 스트리밍은 `VisualAssetSubsystem`의 요청·수명 관리를 사용한다. 전투/탑승 애니메이션 레이어에는 컴포넌트 로컬 `FStreamableHandle` 경로도 남아 있다. 이를 모든 전투 질의·표현 로딩의 단일 서비스로 일반화하지 않는다. 서버 간 이동은 handover envelope/상태 머신/transport 계약이며 실제 라이브 서버 연결 완료를 의미하지 않는다.

직업·전직·능력 부여 및 DA 작성의 최신 계약은 [2026-09-19 확장 기반](../Architecture/Extensions/Extension_Foundation_2026-09-19.md)을 참고한다. 같은 PlayerState 안의 아바타 교체를 지원한다. 후속 로컬 개발 저장은 `-ProjectJLocalProfile=<name>` Development 단독 실행에서 Progression/Quest와 실제 인벤토리·장비를 함께 다룬다. 기존 AssetManager 레지스트리가 안정적인 ItemId/version을 해석하고, 로컬 보상·소비·장착과 기존 직업·전직 변경은 worker의 lease+상태+receipt 커밋이 확정된 뒤 전체 상태를 설치하고 기존 권위 컴포넌트에 게시한다. 초기 로드도 첫 알림 전에 P/Q/소유물/슬롯을 함께 설치한다. 정상 레벨 상승은 XP 경로를 사용하고 동기 개발/hand-over override setter의 저장 우회는 거부한다.

프로젝트 전용 Windows rollback VFS와 전체 snapshot v2를 유지하며, DB container는 구형 writer의 오해석을 막는 version2다. 현재 세션의 경제 명령은 순번 창64개, checkpoint는 최신 결과1개를 보존하고 이전 세션/순번은 만료로 거부한다. 상태·receipt·순번/정리를 같은 transaction에 확정하므로 기존4096회 누적 한도로 정상 저장이 멈추지 않는다. 입장·큐·백업의 유한 한도와 실패 상태, 실측·재시작 검증은 [현재 잔여 작업 기록](../Review/Architecture/Project_J_MMO_Remaining_2026-10-19.md)을 따른다. `Project_JProfileMigration` commandlet은 원본 read-only 검사·dry-run·별도 결과/rollback 복사본을 지원한다. snapshot v1의 누락된 소유물을 추측하지 않고 명시적 입력으로만 이관한다. 실제 사용자 DB 전환과 운영 인증·네트워크/Shipping 저장·실제 handover는 별도 범위다.

## 2. 모듈 경계

```text
Project_JCore
  ├─ 공용 Gameplay Tag, 인터페이스, MMO 식별자, Asset/GameData/Message Subsystem
  └─ 상호작용 공용 계약

Project_JGAS
  ├─ Project J AbilitySystemComponent, AttributeSet, grant lease 공용 계약
  └─ GAS 소유권 계약

Project_JMount
  └─ 지상/비행 탈것, 탈것 Attribute/Animation/Component

Project_JCharacter
  ├─ Mover Pawn, Locomotion, GASP/Pose Match, Animation
  ├─ Combat, Input, Hit Validation, Server-side rewind
  ├─ Inventory, Equipment, Weapon presentation, Character class
  ├─ UI binding, Networking, Mass/NPC, Validation
  └─ 실질적인 플레이어 게임플레이의 중심 모듈

Project_J
  ├─ GameMode / GameState / PlayerState / PlayerController
  ├─ Social, Gateway, Handover 등 게임·백엔드 경계
  └─ 전역 게임 흐름과 진입점

Project_JMMO
  └─ 값 기반 서비스 계약·CAS 메모리 repository·확장 카탈로그

Project_JCharacterEditor
  └─ 에디터 전용 검증·도구 확장

Project_JAnimationNodes
  └─ UncookedOnly 그래프 wrapper; 실행 노드는 Character 모듈
```

의존성은 아래 방향을 유지한다. 하위 모듈이 Character나 Game 모듈을 역참조하지 않도록 한다.

```text
Project_JCore → Project_JGAS → Project_JMount
       └──────────────────────→ Project_JCharacter → Project_J
Project_JMount ───────────────→ Project_JCharacter
엔진 Core → Project_JMMO → Project_J
Project_JCharacter → Project_JAnimationNodes → Project_JCharacterEditor
```

`Project_JMount`는 Core/GAS 공용 계약 위에 있는 탈것 런타임 모듈이며,
현재 `Project_JCharacter`가 이를 사용한다. 따라서 Character 또는 Game 모듈을
Mount가 역참조하지 않도록 한다.

## 3. 런타임 소유권: 가장 먼저 지켜야 할 규칙

### 플레이어와 NPC는 같은 방식으로 상태를 소유하지 않는다

- `AProject_JPlayerCharacter`는 Avatar다. 카메라, 입력, Locomotion, 전투 표현과 캐릭터 조정을 맡는다.
- 플레이어의 장기 상태(ASC, AttributeSet, Inventory, EquipmentManager, ProgressionComponent)는 기본적으로 `AProject_JPlayerState`에 둔다. 재접속·Possess 변경을 고려한 구조다.
- `AProject_JBaseCharacter`는 플레이어/NPC 공통 기반이다. NPC는 PlayerState 없이 자신에게 로컬 ASC/장비 런타임을 둘 수 있다.
- 어떤 시스템이든 `GetAbilitySystemComponent()`, `GetInventoryComponent()`, `ResolveEquipmentManagerForRuntime()` 같은 해석 경로를 우회해 캐릭터에 직접 상태를 중복 생성하면 안 된다.
- ASC 포인터가 살아 있어도 해당 Pawn이 현재 Avatar가 아니면 활성화·취소·상태 조회·입력 해제 권한이 없다. 후속 [전체 감사](../Review/Audits/Project_J_Whole_Project_Audit_2026-10-13.md)에서 실제 교체 시험과 검토 범위를 확인한다.

### 권한과 표현을 분리한다

- 서버: 장비 변경, Gameplay Effect, 능력 결과, 피해 판정, 이동의 최종 권한을 갖는다.
- 소유 클라이언트: 입력 반응과 GAS 예측을 담당한다.
- 모든 클라이언트: 복제된 상태를 바탕으로 무기 표시, 몽타주 등 시각 표현을 재구성한다.
- **게임플레이 상태**와 **애니메이션/무기 표현 상태**는 같은 값이 아니다. 예를 들어 CombatMode의 서버 권한과 Draw/Sheathe 시각 전환은 별도의 수명 주기를 가진다.

## 4. 핵심 실행 흐름

### 입력 → 게임플레이

```text
Enhanced Input (IA / IMC)
  → UProject_JPlayerInputBindingComponent
  → UProject_JSkillInputRouterComponent
  → InputTag.*
  → UProject_JSkillInputExecutionComponent
  → GAS Ability / Gameplay Event
  → 서버 권한 검증 · Gameplay Effect · 복제
```

- 키 자체가 아닌 `InputTag.*`가 게임플레이 의도다.
- 단일 스킬은 AbilitySet이 부여한 GA가 처리한다.
- 연속 입력 명령은 `CombatCommandSet`, 진행 중 공격 연계는 `ComboDefinition`이 담당한다. 둘을 혼합하지 않는다.

### 장비 → 직업 전투 표현

```text
EquipmentItemDefinition
  → EquipmentManager / EquipmentRuntime
  → CombatStyleDefinition + WeaponAnimProfile + WeaponPresentationProfile
  → AbilitySet / Effects / 장비 스탯
  → Combat animation layer / 무기 Actor 표현
```

- 아이템 정의는 소유·장착·시각·전투 스타일을 연결한다.
- `WeaponAnimProfile`은 전투 이동/발도/납도/링크 레이어다.
- `WeaponPresentationProfile`은 무기 Actor와 손·등 소켓 같은 시각 연결만 가진다.
- `AttackDefinition`은 한 공격의 몽타주, 이동 정책, 타격 사양, 피해 Effect다.
- 각 책임을 하나의 DA에 몰아넣지 않는다. 자세한 분리는 [DataAssetQuickReference](../Gameplay/Authoring/Content_Authoring_System.md#data)를 따른다.

### 이동 → 애니메이션

```text
Enhanced Input / NavMover → GAS 정책 검증 → Mover / Network Prediction
  → 물리 lifecycle·UMoverTrajectoryPredictor → GT 불변 snapshot / Proxy
  → GASP State Controller / Pose Match Chooser / BlendStack (지상)
    + Project_J 값 타입 Chooser·실제 재생 시각 유지 (공중 재선택)
  → Warping / Root Offset / Lean / Aim / 공통 DefaultSlot / 발 접지
  → 전투·탈것 Linked Anim Layer / Pose History
  → 리타깃 몸체 / 손 접촉 / 의상 물리 / 장비 Leader Pose
```

- 지상 물리는 원본 SmoothWalking 엔진 solver에 native `Project_JGroundMovementLibrary` 계산을 연결한다. 모드 BP는 native 호출 adapter이며 튜닝은 Mover의 `GroundMovementSettings`다. 승인된 native 입력을 직접 소비하고 별도 BP 입력 투영을 만들지 않는다. native AnimInstance가 프레임 계산과 GASP Chooser/재생 요청을 소유하고 포즈 그래프가 소비한다. worker에서 Pawn의 물리 상태를 다시 조회하지 않는다.
- OTM/Strafe facing과 jump/land episode는 물리 결과에서 가져온다. 공격 권위·판정·몽타주 선택은 GAS가 소유하고 root motion은 Mover에 연결한다.
- 리타깃·의상 표시 예산과 실제 전투/서버 포즈 요구는 기존 coordinator를 사용한다. 이번 이관을 과거 200명 성능 검증의 재통과로 보고하지 않는다.
- 옛 `Project Unified Locomotion`과 CMC TIP·곡선/MM 후보 정책은 이전 기반 자료다. 현재 계약과 남은 한계는 [Mover 이관](../Animation/Architecture/GASP58_Locomotion_Migration_2026-10-19.md)을 따른다.

## 5. 현재 콘텐츠/에셋 작업의 기준

### 생산용 휴머노이드 직업

```text
AProject_JPlayerCharacter
  → AProject_JGreatswordCharacter
    → BP_GreatSword

ABP_Player_Master
  + ALI_HumanoidCombat
  + ABP_Greatsword_Layers
```

- 새 휴머노이드 직업은 얇은 native 직업 클래스 + 해당 Blueprint + 직업 layer/DA 조합으로 확장한다.
- 공통 입력, GAS 소유권, 장비 시스템, SSR, locomotion graph를 직업 Blueprint에 복사하지 않는다.
- `ABP_Player_Master`는 GASP 지상 선택·재생/보정, Project_J 점프 재선택·원본 일반 추락, 슬롯·Aim·접지·Pose History·Mount 선택을 소유한다. 실제 BP_Player/GreatSword/NPC 연결을 저장했다. 직업/몸체 DA의 역할은 유지한다.
- State Controller/Chooser는 gameplay 권위를 갖지 않는다. 물리 입력과 lifecycle은 Mover, 전투·장비 상태는 기존 GAS/장비 컴포넌트가 소유한다.
- 직업 layer는 무기 자세/상체 오버레이/직업 고유 전투 이동 등 **차이가 실제로 필요한 부분만** 구현한다.

### 태그와 데이터의 역할

- `InputTag.*`: 입력 의도
- `State.*`: 지속 상태(CombatMode, Sprinting, Attacking 등)
- `Event.*`: 몽타주 노티파이 등 일회성 Gameplay Event
- `Combo.*`: 콤보 그래프 노드 주소
- `Attack.*`: 개별 공격 정체성
- `Command.*`: 순차 입력 명령 정체성

공유/코드 태그는 `Source/Project_JCore/Public/Project_JGameplayTags.h`, 콘텐츠 태그는 `Config/DefaultGameplayTags.ini`를 먼저 확인한다. 같은 의미의 태그를 자산마다 새로 만들지 않는다.

## 6. 설정과 주요 진입점

| 범주 | 우선 확인 위치 |
| --- | --- |
| 엔진 기본 맵·GameMode | `Config/DefaultEngine.ini` |
| Input Action/Mapping Context 기본 설정 | `Config/DefaultInput.ini` 및 캐릭터의 Input 관련 DA/Blueprint |
| Gameplay Tag | `Config/DefaultGameplayTags.ini`, `Project_JGameplayTags.*` |
| GAS 능력/속성 | `Source/Project_JGAS`와 `Source/Project_JCharacter/Public/AbilitySystem` |
| 플레이어/GameMode/PlayerState | `Source/Project_J/Game/` |
| 캐릭터·이동·애니 | `Source/Project_JCharacter/Public/` 및 `Private/Animation/` |
| 장비·인벤토리 | `Source/Project_JCharacter/Public/Equipment`, `Inventory`, `Components` |
| 탈것 | `Source/Project_JMount` 및 `Docs/Gameplay/Architecture/MountSystemArchitecture.md` |
| 데이터 검증 | `Source/Project_JCharacter/Public/Validation`, `Private/Tests` |

## 7. 새 작업 시작 전 점검 순서

1. 해당 기능이 어느 모듈의 책임인지 먼저 정한다.
2. 해당 시스템의 Data Asset, Gameplay Tag, AbilitySet이 기존에 있는지 `rg`로 확인한다.
3. 플레이어 전용인지, NPC도 공유하는지, 서버 권한이 필요한지 판단한다.
4. 기존 C++ API/컴포넌트를 확장할지, 새 컴포넌트가 정당한지 결정한다.
5. 에셋 연결이 필요한 경우에는 C++/설정 문서로 먼저 확인하고, 실제 Blueprint/DA 값만 에디터에서 최소 범위로 확인한다.
6. C++ 변경 뒤에는 `Project_JEditor Win64 Development` 빌드를 실행한다.
7. 네트워크·표현 변경은 최소 2인 PIE에서 소유자와 simulated proxy를 모두 확인한다.

## 8. 자주 발생하는 오해와 금지 사항

- 생산 휴머노이드는 현재 공통 `ABP_Player_Master`와 직업 Linked Anim Layer를 사용한다. `BP_Player`는 공통 아바타 제작 기반이고, 퇴역한 `ABP_Player`/`ABP_Humanoid_Master`를 새 제작 경로로 복원하지 않는다.
- 아이템 장착 여부와 손에 든/등에 멘 무기 표현을 같은 bool 하나로 처리하지 않는다.
- InputTag를 몽타주 이름 또는 직업 이름으로 과도하게 세분화하지 않는다.
- 직업마다 PlayerCharacter, 공통 AnimGraph, GA 기반 로직을 복사하지 않는다.
- 일반 locomotion을 Root Motion으로 바꾸지 않는다. Root Motion은 커밋된 공격/회피/돌진에 한정한다.
- Client의 애니메이션 결과를 피해·장비·전투 상태의 권위로 사용하지 않는다.
- 현재 필요하지 않은 백엔드/대규모 MMO 시스템을 미리 완성하려 하지 않는다. 계약과 경계만 유지한다.

## 9. 검증 및 디버깅

유용한 PIE 콘솔 명령:

```text
DumpMMOState
DumpAnimBudget
DumpReplicationPolicy
DumpCharacterComponents
DumpCombatState
DumpMMOProfilingSnapshot [MaxDetailedCharacters]
```

현재 로코모션의 회귀·제작·진단 경로는 [GASP 5.8 이관 기록](../Animation/Architecture/GASP58_Locomotion_Migration_2026-10-19.md)의 마지막 절을 따른다. 퇴역한 구형 MM CVar나 전용 노드를 복원하지 않는다. 에셋 Validation 오류는 실제 메시지와 참조를 먼저 확인하고, 폴더 변경 뒤 남은 Redirector/Soft Reference가 원인으로 확인되면 해당 연결을 정리한다.

## 10. 이 문서 다음에 읽을 전문 문서

- 전체 방향/보류 범위: [ProjectOverview](ProjectOverview.md), [MMORPGArchitectureReview](../Review/Architecture/MMORPGArchitectureReview.md), [DeferredMMORPGSystems](../Architecture/Planning/DeferredMMORPGSystems.md)
- GAS·AbilitySet·Input: [SkillSystemArchitecture](../Gameplay/Architecture/SkillSystemArchitecture.md)
- 장비·직업·DA: [DataAssetQuickReference](../Gameplay/Authoring/Content_Authoring_System.md#data), [ContentExpansionGuide](../Gameplay/Authoring/Content_Authoring_System.md#expansion)
- 전투·콤보·무기·애니메이션: [CombatLocomotionArchitecture](../Combat/Architecture/Combat_Animation_System.md#layers), [CombatAnimationComposition](../Combat/Architecture/Combat_Animation_System.md#composition)
- 현재 GASP 로코모션·원격 표현·회귀: [GASP 5.8 이관 기록](../Animation/Architecture/GASP58_Locomotion_Migration_2026-10-19.md). [MotionMatchingNextSteps](../Animation/Architecture/MotionMatchingNextSteps.md)는 이전 MM 경로의 역사 자료다.
- 탈것: [MountSystemArchitecture](../Gameplay/Architecture/MountSystemArchitecture.md)

## 새 Codex 채팅에 붙여 넣을 최소 컨텍스트

```text
UE 5.8 C++ Project J 작업이다. 먼저 Docs/Overview/ProjectContext.md와 기능별 관련 문서를 읽고,
Source/Config를 좁게 분석한 뒤 작업해줘. BP_Player는 공통 아바타 제작 기반이며,
생산 휴머노이드 기준은 AProject_JPlayerCharacter → 직업 native class → BP_직업,
ABP_Player_Master + 직업 Linked Anim Layer 구조다. 이동은 Mover와 native GASP 계산,
포즈는 GASP State Controller/Pose Match/BlendStack을 사용한다. OTM/Strafe와 현재 점프
공중 재선택·playhead 연속성을 유지하고, 퇴역한 Master/MM fallback을 복원하지 마.
플레이어의 장기 상태는 PlayerState 우선,
서버 권한과 클라이언트 표현을 분리한다. C++ 변경 후에는 Project_JEditor Win64 Development를 빌드해줘.
기존 사용자 코드·에셋 변경을 보존하고 AGENTS.md의 빌드 안전 규칙을 지켜줘.
작업에 필요하면 MCP·컴퓨터 사용을 별도 도구 사용 허락 없이 활용해줘.
현재 요청에 필요한 관련 변경·저장은 진행하되 작업 범위 밖으로 확대하거나 접근 제한을 우회하지 마.
```
